package com.tsc.interfaces.author.core.configuration;


import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Mixed media Scheduler configuration 0CD", description = "Mixed media Scheduler configuration 0CD description"

)

public @interface MediaAssetConfiguration {


    @AttributeDefinition(

            name = "Mixed media Scheduler configuration 0CD",

            description = "Mixed media Scheduler configuration 0CD description",

            type = AttributeType.STRING) String scheduler_name() default "practice";


    @AttributeDefinition(

            name = "Mixed media Scheduler configuration Cron job expression",

            description = "Mixed media Scheduler configuration Cron job expression",

            type = AttributeType.STRING) String scheduler_expression() default "* * * * * ? *";


    @AttributeDefinition(

            name = "Enable Scheduler",

            description = "Enable Scheduler",

            type = AttributeType.BOOLEAN) boolean enable_scheduler() default true;

    @AttributeDefinition(

            name = "Concurrent Scheduler", description = "Concurrent Scheduler", type = AttributeType.BOOLEAN) boolean concurrent_scheduler() default false;


    @AttributeDefinition(

            name = "Custom Property",

            description = "Custom Property", type = AttributeType.STRING) String customProperty() default "Test";
}
