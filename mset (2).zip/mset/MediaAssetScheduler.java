package com.tsc.interfaces.author.core.schedulers;

import com.tsc.interfaces.author.core.services.MediaAssetService;
import com.tsc.interfaces.author.core.configuration.MediaAssetConfiguration;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.service.component.annotations.*;
import org.osgi.service.metatype.annotations.Designate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Component(service = MediaAssetScheduler.class, immediate=true)
@Designate(ocd = MediaAssetConfiguration.class)

public class MediaAssetScheduler implements Runnable {

    private final Logger logger = LoggerFactory.getLogger(getClass());


    @Reference
    private Scheduler scheduler;


    @Reference
    private MediaAssetService mediaAssetService;

    @Activate

    protected void activate(final MediaAssetConfiguration config) {

        logger.error("MediaAssetScheduler activate method called");

        addScheduler(config);
    }


    public void addScheduler(MediaAssetConfiguration config) {

        logger.error("Mixed media Scheduler added successfully");

        if (config.enable_scheduler()) {

            ScheduleOptions options = scheduler.EXPR(config.scheduler_expression());
            options.name(config.scheduler_name());

            options.canRunConcurrently(config.concurrent_scheduler());


            scheduler.schedule(this, options);

            logger.error("Mixed media Scheduler added successfully name ='{}'", config.scheduler_name());
        } else {
            logger.error("MediaAssetScheduler disabled");
        }
    }


    public void removeScheduler(MediaAssetConfiguration config) {
        scheduler.unschedule(config.scheduler_name());

    }


    @Deactivate
    protected void deactivate(MediaAssetConfiguration config) {
        removeScheduler(config);

    }


    @Modified
    protected void modified(MediaAssetConfiguration config) {

        removeScheduler(config);

        addScheduler(config);
    }

    @Override
    public void run() {

        logger.error("MediaAssetScheduler run >>>>>>");

        Integer success = mediaAssetService.createMediaAsset();
        logger.error("MediaAssetScheduler success >>>>>>>{}", success);
    }
}


