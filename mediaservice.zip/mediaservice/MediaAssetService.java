package com.tsc.interfaces.author.core.services;

import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.AssetManager;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import org.apache.sling.api.resource.*;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import java.text.SimpleDateFormat;
import java.util.*;

@Component(service = MediaAssetService.class)

public class MediaAssetService {

    @Reference
    private ResourceResolverFactory resolverFactory;

    @Reference
    private QueryBuilder queryBuilder;
    private String environmentName = "TractorSupplycompanyQA";
    private String productPath = "/content/dam/tsc/product";
    private String mixMediaPath = "/content/dam/tsc/mixmedia";
    private final Logger logger = LoggerFactory.getLogger(getClass());

    public Integer createMediaAsset() {

        logger.error("Media set service ******");
        Map<String, Object> param = new HashMap();
        param.put(ResourceResolverFactory.SUBSERVICE, "writeservice");

        try (ResourceResolver resourceResolver = resolverFactory.getServiceResourceResolver(param)) {
            TreeSet<String> skuList = new TreeSet<>();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            Date todayDate = new Date();
            Date yesterdayDate = new Date();
            yesterdayDate.setDate(yesterdayDate.getDate() - 1);
            Map<String, String> skuQueryMap = new HashMap<>();
            skuQueryMap.put("path", productPath);
            skuQueryMap.put("type", "dam:Asset");
            skuQueryMap.put("daterange.property", "jcr:content/jcr:lastModified");
            skuQueryMap.put("daterange.lowerBound", formatter.format(yesterdayDate));
            skuQueryMap.put("daterange.upperBound", formatter.format(todayDate));
            skuQueryMap.put("property", "jcr:content/metadata/tsc:SKU");
            skuQueryMap.put("property.operation", "exists");
            skuQueryMap.put("p.limit", "-1");

            Query skuQuery = queryBuilder.createQuery(PredicateGroup.create(skuQueryMap), resourceResolver.adaptTo(Session.class));

            List<Hit> skuHits = skuQuery.getResult().getHits();

            for (Hit hit : skuHits) {
                Resource resource = hit.getResource();
                skuList.add(resource.getChild("jcr:content/metadata").getValueMap().get("tsc:SKU", String.class));

            }

            for (String skuId : skuList) {

                String assetName = skuId + "_mset";
                logger.error("Media set service kk** 3");
                String firstSeg = skuId.substring(1, 3);
                String secondSeg = skuId.substring(3, 5);
                String thirdSeg = skuId.substring(5, 7);
                String assetPath = productPath + "/" + skuId.substring(0,1) + "/" + firstSeg + "/" + secondSeg + "/" + thirdSeg + "/" + assetName;
                logger.error(" Media set service one ** }", queryBuilder);


                logger.error("Media set service one ****** {}", queryBuilder);
                Map<String, String> map = new HashMap<>();
                map.put("path", productPath);
                map.put("type", "dam:Asset");
                map.put("property.value", skuId);
                map.put("property", "jcr:content/metadata/tsc:SKU");
                map.put("p.limit", "-1");
                logger.error("Media set service MAP ****** {}", map.toString());
                Query query = queryBuilder.createQuery(PredicateGroup.create(map), resourceResolver.adaptTo(Session.class));
                List<Hit> hits = query.getResult().getHits();
                logger.error("Media set service ****** 2");
                List<String> paths = new ArrayList<>();

                for (Hit hit : hits) {
                    paths.add(hit.getPath());
                }
                logger.error("Media set service {} Path", paths.size());
                if (null != resourceResolver) {


                    Resource resource = resourceResolver.getResource(assetPath);

                    if (null == resource) {

                        AssetManager assetManager = resourceResolver.adaptTo(AssetManager.class);
                        Asset multiMediaSetResource = assetManager.createAsset(assetPath, null, null, true);


                        Calendar cal = new GregorianCalendar();

                        Resource metadataRes = multiMediaSetResource.adaptTo(Resource.class).getChild("jcr:content/metadata");

                        Resource related = multiMediaSetResource.adaptTo(Resource.class).getChild("jcr:content/related");
                        Resource jcr = multiMediaSetResource.adaptTo(Resource.class).getChild("jcr:content");

                        updateJcrContent(jcr, cal);
                        updateMetaData(metadataRes, assetName, cal);

                        updateRelatedAsset(related, paths);
                        resourceResolver.commit();

                    } else {
                        Resource related = resource.getChild("jcr:content/related");
                        Resource metadataRes = resource.getChild("jcr:content/metadata");
                        updateRequiredMetadata(metadataRes, skuId, assetName);
                        updateRelatedAsset(related, paths);
                    }
                    logger.error("Media set service ****** 4");
                    resourceResolver.commit();


                    return 200;
                }
            }
        } catch (LoginException e) {
            logger.error("Media set One service ****** {}", e.getMessage());
            e.printStackTrace();
        } catch (PersistenceException e) {
            logger.error("Media set Two service ****** {}", e.getMessage());
        } catch (RepositoryException e) {
            logger.error("Media set this service ****** {}", e.getMessage());
            e.printStackTrace();
        }


        return 650;
    }

    private void updateMetaData(Resource metadataRes, String assetName, Calendar cal) {
        ModifiableValueMap modifiableValueMap = metadataRes.adaptTo(ModifiableValueMap.class);
        modifiableValueMap.put("dam:scene7APIServer", "https://s7sps1apissl.scene7.com");
        modifiableValueMap.put("dam:scene7CloudConfigPath", "/conf/globalL/settings/cloudconfigs/dmscene7");
        modifiableValueMap.put("dam:scene7CompanyID", "c|237360");
        modifiableValueMap.put("dam:scene7Domain", "https://tractorsupplyga.scene7.com/");
        modifiableValueMap.put("dam:scene7File", environmentName + "/" + assetName);
        modifiableValueMap.put("dam:scene7FileStatus", "PublishComplete");
        modifiableValueMap.put("dam:scene7Folder", environmentName + "/tsc/product/6/15/20/22/");
        modifiableValueMap.put("dam:scene7ID", "a|1579841246");
        modifiableValueMap.put("dam:scene7LastModified", cal.getTime().getTime());
        modifiableValueMap.put("dam:scene7Name", assetName);
        modifiableValueMap.put("dam:scene7PublishTimeStamp", cal);
        modifiableValueMap.put("dam:scene7PublishedBy", "'serviceUser");
        modifiableValueMap.put("dam:scene7Type", "MediaSet");
        modifiableValueMap.put("dc:format", "Multipart/Related; typemapplication/x-MixedMediaSet");
        modifiableValueMap.put("dc:modified", cal);
        modifiableValueMap.put("dc:title", assetName);
        modifiableValueMap.put("jcr:lastModified", cal);
        modifiableValueMap.put("jcr:LastModifiedBy", "serviceUser");

        Calendar cal2 = new GregorianCalendar();
        Date date = new Date();
        date.setYear(date.getYear() + 1);
        cal2.setTime(date);

        modifiableValueMap.put("prism:expirationDate", cal2);
        modifiableValueMap.put("tsc0:assetType", "MediaSet");
        modifiableValueMap.put("tsc0:rightsHolder", "TSC");
        modifiableValueMap.put("tsc0:rightsUsage", "FullyOwned");

        logger.error("Media set service MAP ****** Update meta data");

    }

    private void updateRelatedAsset(Resource related, List<String> paths) throws RepositoryException {
        Node node = related.adaptTo(Node.class);
        if (null != node) {
            Node s7Set = getRequiredNode(node, "s7set");
            s7Set.setProperty("sling:resourceType", "sling/collection");
            Node slingMembers = getRequiredNode(s7Set, "sling:members");
            String[] pathArray = new String[paths.size()];
            slingMembers.setProperty("sling:resource", paths.toArray(pathArray));
            for (String path : paths) {
                String fileName = path.substring(path.lastIndexOf("/") + 1, path.length());
                Node fileNameNode = getRequiredNode(slingMembers, fileName);
                fileNameNode.setProperty("sling:resource", path);
            }
        }
    }

    private Node getRequiredNode(Node node, String nodeId) throws RepositoryException {
        Node nodeResource = null;
        if (!node.hasNode(nodeId)) {
            nodeResource = node.addNode(nodeId);
        } else {
            nodeResource = node.getNode(nodeId);
        }
        return nodeResource;
    }

    private void updateRequiredMetadata(Resource metadataRes, String assetName, String skuId) {
        ModifiableValueMap modifiableValueMap = metadataRes.adaptTo(ModifiableValueMap.class);
        modifiableValueMap.put("dam:scene7APIServer", "https://s7sps1apissl.scene7.com");
        modifiableValueMap.put("dam:scene7CloudConfigPath", "/conf/globalL/settings/cloudconfigs/dmscene7");
        modifiableValueMap.put("dam:scene7CompanyID", "c|163868");
        modifiableValueMap.put("dam:scene7Domain", "https://tractorsupplydev.scene7.com/");
        modifiableValueMap.put("dam:scene7File", "TractorSupplyCompanyDev/mset_" + skuId);
        modifiableValueMap.put("dam:scene7ID", "a|1589891340");
        modifiableValueMap.put("dam:scene7Name", assetName);


    }

    private void updateJcrContent(Resource jcr, Calendar cal) {

        ModifiableValueMap modifiableValueMap = jcr.adaptTo(ModifiableValueMap.class);

        modifiableValueMap.put("dam:assetState", "processed");
        modifiableValueMap.put("dam:imageServerAsset", true);
        modifiableValueMap.put("dam:lastS7SyncStatus", "success");
        modifiableValueMap.put("dam:lastS7Synced", cal);
        modifiableValueMap.put("dam:s7damType", "MixedMediaSet");
        modifiableValueMap.put("dam:scene7L.astPublished", cal);
        modifiableValueMap.put("jcr:lastModifiedBy", "writeservice");
        modifiableValueMap.put("jcr:lastModified", cal);
        modifiableValueMap.put("status", "Finished");

        logger.error("Media set service MAP ****** updateJcrContent");
    }
}